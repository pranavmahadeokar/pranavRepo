# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('ut_theory.csv')

#Removing outliers
def out_detect(col):
    outlier =[]
    mean = np.mean(dataset[col])  
    std = np.std(dataset[col])
    threshold = 2.7
    for i in dataset[col]:
        zscore = (i - mean)/std
        if abs(zscore) > threshold:
            outlier.append(i)
    return outlier

def out_replace(outlier):
    global dataset
    dataset = dataset.replace(to_replace = outlier, value = np.nan)
    dataset = dataset.dropna(axis = 0, how = 'any')
    return dataset


outlier = out_detect('ut')
dataset = out_replace(outlier)



# X and Y assignment
X = dataset.iloc[:, 0].values
y = dataset.iloc[:, 1].values
X = np.reshape(X, (-1, 1))
y = np.reshape(y, (-1, 1))


# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)


#Linear Regression
import statsmodels.api as sm
X = sm.add_constant(X)
regressor = sm.OLS(y_train, X_train)
results = regressor.fit()
results.summary()

#Predicting the results
y_pred = results.predict(X_train)

#Visualization of results
plt.scatter(X_train, y_train)
plt.plot(X_train, y_pred, c = "red")
plt.show()

#Model Evaluation
def model_eval(fit_type, Xvar, yvar, cvvar):
    from sklearn.model_selection import cross_val_score
    cv = cross_val_score(estimator = fit_type , X = Xvar, y = yvar, cv = cvvar)
    print(cv)
    mean = cv.mean()
    std = cv.std()
    print("MEAN :{}".format(mean))
    print("Standard Deviation: {}".format(std))

#Calling the function
model_eval(regressor, X_train , y_train , 10)





# RandomForest Regressor
from sklearn.ensemble import RandomForestRegressor
regressor = RandomForestRegressor(n_estimators = 10, criterion = 'mse', random_state= 0)
regressor.fit(X_train, y_train)
y_pred = np.reshape(y_pred, (-1, 1))
y_pred = regressor.predict(X_test)
#above statement is used for prediction
#The result is stored in 'y_pred' variable!
#y_pred = classifier.predict(Here specify the dat we want to predict.)
#Use this model only! Others were used to to test model performance




# Visualising the Random Forest Regression results (higher resolution)
X_grid = np.arange(min(X_test), max(X_test), 0.01)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(X_test, y_test, color = 'red')
plt.plot(X_grid, regressor.predict(X_grid), color = 'blue')
plt.title('UT vs Theory')
plt.xlabel('Unit test')
plt.ylabel('Theory')
plt.show()
