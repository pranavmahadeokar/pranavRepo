# Logistic Regression

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('pointer_results.csv')
X = dataset.iloc[:, 0:4].values
y = dataset.iloc[:, -1].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.15, random_state = 256)

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)
# X = sc.transform(X)

#Logistic Classification model
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0, solver ='liblinear')
classifier.fit(X, y)
y_pred = classifier.predict(X)
#above statement is used for prediction
#The result is stored in 'y_pred' variable!
#y_pred = classifier.predict(Here specify the dat we want to predict.)
#Use this model only! Others were used to to test model performance


#Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y, y_pred)

#Model Evaluation
def model_eval(fit_type, Xvar, yvar, cvvar):
    from sklearn.model_selection import cross_val_score
    cv = cross_val_score(estimator = fit_type , X = Xvar, y = yvar, cv = cvvar)
    print(cv)
    mean = cv.mean()
    std = cv.std()
    print("MEAN :{}".format(mean))
    print("Standard Deviation: {}".format(std))

model_eval(classifier, X, y, 10)

#SVM classification
from sklearn.svm import SVC
classifier = SVC(kernel = 'rbf', random_state = 256)
classifier.fit(X, y)
y_pred = classifier.predict(X)

#Confusion Matrix
cm = confusion_matrix(y, y_pred)

#Applying XGBOOST
from xgboost import XGBClassifier
classifier = XGBClassifier(booster = 'dart')
classifier.fit(X_train, y_train)
y_pred = classifier.predict(X, y.all())
cm = confusion_matrix(y, y_pred)
