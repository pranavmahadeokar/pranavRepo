# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error

# Importing the dataset
dataset = pd.read_csv('pointer_results.csv')
X = dataset.iloc[:, [0, 2]].values
y = dataset.iloc[:, 4].values
y = np.reshape(y, (-1, 1))

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 10)


#Fitting Linear regression 
from sklearn.linear_model import LinearRegression
reg = LinearRegression()
reg.fit(X_train, y_train)
y_pred = reg.predict(X_test)

#above statement is used for prediction
#the result is stored in 'y_pred' variable!
#y_pred = classifier.predict(Here specify the dat we want to predict.)
#use this model only! Others were used to to test model performance

#Model evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print("Mean Squared error: {}".format(mse))
print("R2 Score: {}".format(r2))

# Applying K-fold validation
from sklearn.model_selection import cross_val_score
cv = cross_val_score(estimator = reg, X = X_train, y = y_train, cv = 10 )
cv.mean()
cv.std()




# Fitting Random Forest Regression to the dataset
from sklearn.ensemble import RandomForestRegressor
regressor = RandomForestRegressor(n_estimators = 10, random_state = 0)
regressor.fit(X_train, y_train)
y_pred = regressor.predict(X_test)

#Model Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print("Mean Squared error: {}".format(mse))
print("R2 Score: {}".format(r2))


# Applying K-fold validation
from sklearn.model_selection import cross_val_score
cv = cross_val_score(estimator = regressor, X = X_train, y = y_train, cv = 10 )
cv
cv.mean()
cv.std()



# Fitting SVR regression Model
from sklearn.svm import SVR
rbf = SVR(kernel = 'rbf')
rbf.fit(X_train, y_train)
y_pred = rbf.predict(X_test)

#Model Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print("Mean Squared error: {}".format(mse))
print("R2 Score: {}".format(r2))

# Applying K-fold validation
from sklearn.model_selection import cross_val_score
cv = cross_val_score(estimator = rbf, X = X_train, y = y_train, cv = 10 )
cv
cv.mean()
cv.std()







